export interface Seller {
    id: string;
    name?: string;
    email?: string;
  
    [key: string]: unknown;
  }
  