/** @type {import('next').NextConfig} */
const config = {};

export default config;
